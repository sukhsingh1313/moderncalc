// let a= 20;
// const b = 20;

// console.log(a);
// {
//   let a = 50;
//   console.log(a);
  
// }
for (let i = 1;i<=20000;i++) {
 console.log(i)
  
}

// let c = a*b;
// console.log(typeof(a));
// console.log(typeof(b));

// console.log(c);

